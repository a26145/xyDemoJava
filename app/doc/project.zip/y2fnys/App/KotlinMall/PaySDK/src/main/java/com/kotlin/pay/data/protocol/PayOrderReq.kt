package com.kotlin.pay.data.protocol

/*
    支付订单
 */
data class PayOrderReq(val orderId:Int)
