package com.kotlin.provider.event

/*
    消息标签是否显示事件
 */
class MessageBadgeEvent(var isVisible:Boolean)
