package com.kotlin.base.ui.fragment

import com.trello.rxlifecycle.components.support.RxFragment

/*
    Fragment基类，业务无关
 */
open class BaseFragment : RxFragment()
