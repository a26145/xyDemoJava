package com.kotlin.order.data.protocol

/*
    刪除收货地址
 */
data class DeleteShipAddressReq(val id: Int)
