package com.kotlin.order.data.protocol

/*
    取消订单
 */
data class CancelOrderReq(val orderId:Int)
