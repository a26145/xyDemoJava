package com.kotlin.order.data.protocol

/*
    提交订单
 */
data class SubmitOrderReq(val order: Order)
