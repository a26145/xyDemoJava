package com.kotlin.goods.event

/*
    购物车全选事件
 */
class CartAllCheckedEvent(val isAllChecked:Boolean)
