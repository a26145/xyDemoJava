package com.kotlin.goods.event

/*
    更新总价事件
 */
class UpdateTotalPriceEvent
