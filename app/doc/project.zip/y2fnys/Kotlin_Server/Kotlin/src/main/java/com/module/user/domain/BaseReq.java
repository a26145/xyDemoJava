package com.module.user.domain;

import java.io.Serializable;

public class BaseReq
        implements Serializable {
}
