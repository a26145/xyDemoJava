/*     */ package com.module.user.model;
/*     */ 
/*     */ public class UserInfo
/*     */ {
/*     */   private Integer id;
/*     */   private String userName;
/*     */   private String userPwd;
/*     */   private String userMobile;
/*     */   private String userIcon;
/*     */   private String userRealName;
/*     */   private String userIdentityCard;
/*     */   private String userNickName;
/*     */   private String userGender;
/*     */   private String userBirthday;
/*     */   private String userAddress;
/*     */   private String userSign;
/*     */   private String pushId;
/*     */ 
/*     */   public Integer getId()
/*     */   {
/*  31 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(Integer id) {
/*  35 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getUserName() {
/*  39 */     return this.userName;
/*     */   }
/*     */ 
/*     */   public void setUserName(String userName) {
/*  43 */     this.userName = (userName == null ? null : userName.trim());
/*     */   }
/*     */ 
/*     */   public String getUserPwd() {
/*  47 */     return this.userPwd;
/*     */   }
/*     */ 
/*     */   public void setUserPwd(String userPwd) {
/*  51 */     this.userPwd = (userPwd == null ? null : userPwd.trim());
/*     */   }
/*     */ 
/*     */   public String getUserMobile() {
/*  55 */     return this.userMobile;
/*     */   }
/*     */ 
/*     */   public void setUserMobile(String userMobile) {
/*  59 */     this.userMobile = (userMobile == null ? null : userMobile.trim());
/*     */   }
/*     */ 
/*     */   public String getUserIcon() {
/*  63 */     return this.userIcon;
/*     */   }
/*     */ 
/*     */   public void setUserIcon(String userIcon) {
/*  67 */     this.userIcon = (userIcon == null ? null : userIcon.trim());
/*     */   }
/*     */ 
/*     */   public String getUserRealName() {
/*  71 */     return this.userRealName;
/*     */   }
/*     */ 
/*     */   public void setUserRealName(String userRealName) {
/*  75 */     this.userRealName = (userRealName == null ? null : userRealName.trim());
/*     */   }
/*     */ 
/*     */   public String getUserIdentityCard() {
/*  79 */     return this.userIdentityCard;
/*     */   }
/*     */ 
/*     */   public void setUserIdentityCard(String userIdentityCard) {
/*  83 */     this.userIdentityCard = (userIdentityCard == null ? null : userIdentityCard.trim());
/*     */   }
/*     */ 
/*     */   public String getUserNickName() {
/*  87 */     return this.userNickName;
/*     */   }
/*     */ 
/*     */   public void setUserNickName(String userNickName) {
/*  91 */     this.userNickName = (userNickName == null ? null : userNickName.trim());
/*     */   }
/*     */ 
/*     */   public String getUserGender() {
/*  95 */     return this.userGender;
/*     */   }
/*     */ 
/*     */   public void setUserGender(String userGender) {
/*  99 */     this.userGender = (userGender == null ? null : userGender.trim());
/*     */   }
/*     */ 
/*     */   public String getUserBirthday() {
/* 103 */     return this.userBirthday;
/*     */   }
/*     */ 
/*     */   public void setUserBirthday(String userBirthday) {
/* 107 */     this.userBirthday = (userBirthday == null ? null : userBirthday.trim());
/*     */   }
/*     */ 
/*     */   public String getUserAddress() {
/* 111 */     return this.userAddress;
/*     */   }
/*     */ 
/*     */   public void setUserAddress(String userAddress) {
/* 115 */     this.userAddress = (userAddress == null ? null : userAddress.trim());
/*     */   }
/*     */ 
/*     */   public String getUserSign() {
/* 119 */     return this.userSign;
/*     */   }
/*     */ 
/*     */   public void setUserSign(String userSign) {
/* 123 */     this.userSign = (userSign == null ? null : userSign.trim());
/*     */   }
/*     */ 
/*     */   public String getPushId() {
/* 127 */     return this.pushId;
/*     */   }
/*     */ 
/*     */   public void setPushId(String pushId) {
/* 131 */     this.pushId = pushId;
/*     */   }
/*     */ }

/* Location:           E:\WorkSpace\App\Test\appidzbnbo3hx6t\ROOT\WEB-INF\classes\
 * Qualified Name:     com.module.user.model.UserInfo
 * JD-Core Version:    0.6.2
 */