package com.module.user.domain;

public class SendVerifyCodeResp extends BaseResp {
}